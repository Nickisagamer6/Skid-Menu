﻿using dark.efijiPOIWikjek;
using ExitGames.Client.Photon;
using GorillaExtensions;
using GorillaGameModes;
using GorillaLocomotion;
using GorillaNetworking;
using GTAG_NotificationLib;
using HarmonyLib;
using MalachiTemp.UI;
using MalachiTemp.Utilities;
using Pathfinding.Util;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using Text = UnityEngine.UI.Text;


namespace MalachiTemp.Backend
{
    /*
       PROTECTION NOTE: THIS TEMPLATE IS PROTECTED MATERIAL FROM "Project Malachi". 
       IF ANY MATERIAL FROM "MalachiTemp" FOUND IN ANY OTHER PROJECT/THING WITHOUT 
       CREDIT OR PERMISSION MUST AND WILL BE REMOVED IMMEDIATELY
    */
    internal class Mods : MonoBehaviour
    {
        // Double click a grey square to open it, click the - in the box to the left of "#region" to close it
        #region Shit
        public static void DisableButton(string name)
        {
            GetButton(name).enabled = new bool?(false);
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void PLACEHOLDER()
        {
            // DONT PUT ANYTHING IN HERE
        }
        public static void DrawHandOrbs()
        {
            orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            orb2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Destroy(orb.GetComponent<Rigidbody>());
            Destroy(orb.GetComponent<SphereCollider>());
            Destroy(orb2.GetComponent<Rigidbody>());
            Destroy(orb2.GetComponent<SphereCollider>());
            orb.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            orb2.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            orb.transform.position = GorillaTagger.Instance.leftHandTransform.position;
            orb2.transform.position = GorillaTagger.Instance.rightHandTransform.position;
            orb.GetComponent<Renderer>().material.color = CurrentGunColor;
            orb2.GetComponent<Renderer>().material.color = CurrentGunColor;
            Destroy(orb, Time.deltaTime);
            Destroy(orb2, Time.deltaTime);
        }
        #endregion
        #region Movement
        public static void FlyMeth(float speed)
        {
            if (WristMenu.abuttonDown)
            {
                GorillaLocomotion.GTPlayer.Instance.transform.position += GorillaLocomotion.GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * speed;
                GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }
        public static void Platforms()
        {
            PlatformsThing(invisplat, stickyplatforms);
        }
        public static void Invisableplatforms()
        {
            PlatformsThing(true, false);
        }
        public static void Noclip()
        {
            foreach (MeshCollider m in Resources.FindObjectsOfTypeAll<MeshCollider>())
            {
                if (WristMenu.triggerDownR)
                {
                    m.enabled = false;
                }
                else
                {
                    m.enabled = true;
                }
            }
        }
        public static void Speedboost() //Normal Boost
        {
            Boost(6);
        }
        public static void Mosaboost() //Light Boost
        {
            Boost(3);
        }
        public static void CrazyBoost() //Very Fast Boost
        {
            Boost(99f);
        }
        public static void InsaneBoost() //Jump But You Teleport LOL
        {
            Boost(999f);
        }
        public static void Boost(float num)
        {
            GTPlayer.Instance.jumpMultiplier = num;
        }
        //By Menker

        // Token: 0x0600009F RID: 159 RVA: 0x000026AA File Offset: 0x000008AA
        public static void ResetArms()
        {
            GorillaLocomotion.GTPlayer.Instance.transform.localScale = new Vector3(1f, 1f, 1f);
        }

        // Token: 0x060000A7 RID: 167 RVA: 0x00005868 File Offset: 0x00003A68
        public static void StickLongArms()
        {
            GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.transform.position = GorillaTagger.Instance.leftHandTransform.position + GorillaTagger.Instance.leftHandTransform.forward * 0.917f;
            GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.transform.position = GorillaTagger.Instance.rightHandTransform.position + GorillaTagger.Instance.rightHandTransform.forward * 0.917f;
        }

       


        // Token: 0x0600013C RID: 316 RVA: 0x0001C94A File Offset: 0x0001AB4A
        public static Transform BC()
        {
            return Mods.Loco().bodyCollider.transform;
        }

        // Token: 0x0600013D RID: 317 RVA: 0x0001C95B File Offset: 0x0001AB5B
        public static VRRig OwnRig()
        {
            return Mods.GetOwnRig();
        }

        // Token: 0x06000005 RID: 5 RVA: 0x00002119 File Offset: 0x00000319
        public static VRRig GetVRRigFromPlayer(Player p)
        {
            return GorillaGameManager.instance.FindPlayerVRRig(p);
        }

        // Token: 0x06000006 RID: 6 RVA: 0x0000212B File Offset: 0x0000032B
        public static List<VRRig> GetAllRigs(bool i = true)
        {
            return i ? GorillaParent.instance.vrrigs : Mods.GetOtherRigs();
        }

        // Token: 0x06000007 RID: 7 RVA: 0x00002144 File Offset: 0x00000344
        public static List<VRRig> GetOtherRigs()
        {
            List<VRRig> list = new List<VRRig>();
            foreach (VRRig vrrig in Mods.GetAllRigs(true))
            {
                bool flag = !vrrig.isOfflineVRRig && !list.Contains(vrrig);
                if (flag)
                {
                    list.Add(vrrig);
                }
            }
            return list;
        }

        // Token: 0x06000008 RID: 8 RVA: 0x000021C8 File Offset: 0x000003C8
        public static Player GetPlayerFromVRRig(VRRig p)
        {
            return p.Creator.GetPlayerRef();
        }

        // Token: 0x06000009 RID: 9 RVA: 0x000021D5 File Offset: 0x000003D5
        public static NetworkView GetNetworkFromRig(VRRig r)
        {
            return (NetworkView)Traverse.Create(r).Field("netView").GetValue();
        }

        // Token: 0x0600000A RID: 10 RVA: 0x000021F1 File Offset: 0x000003F1
        public static NetPlayer GetNetFromRig(VRRig r)
        {
            return RigShit.GetNetworkFromRig(r).Owner;
        }

        // Token: 0x0600000B RID: 11 RVA: 0x000021FE File Offset: 0x000003FE
        public static List<NetPlayer> GetAllNets(bool i)
        {
            return i ? NetworkSystem.Instance.AllNetPlayers.ToList<NetPlayer>() : NetworkSystem.Instance.PlayerListOthers.ToList<NetPlayer>();
        }

        // Token: 0x0600000C RID: 12 RVA: 0x00002223 File Offset: 0x00000423
        public static List<Player> GetAllPlayers(bool i)
        {
            return i ? PhotonNetwork.PlayerList.ToList<Player>() : PhotonNetwork.PlayerListOthers.ToList<Player>();
        }

        // Token: 0x0600000D RID: 13 RVA: 0x0000223E File Offset: 0x0000043E
        public static VRRig GetRigFromNet(NetPlayer p)
        {
            return RigShit.GetVRRigFromPlayer(p.GetPlayerRef());
        }

        // Token: 0x0600000E RID: 14 RVA: 0x0000224B File Offset: 0x0000044B
        public static VRRig GetOwnRig()
        {
            return VRRig.LocalRig;
        }


        // Token: 0x04000003 RID: 3
        public static int r;

        // Token: 0x0600013E RID: 318 RVA: 0x0001C962 File Offset: 0x0001AB62
        public static GTPlayer Loco()
        {
            return GTPlayer.Instance;
        }

        // Token: 0x0600013F RID: 319 RVA: 0x0001C969 File Offset: 0x0001AB69
        public static GorillaTagger GIn()
        {
            return GorillaTagger.Instance;
        }

        // Token: 0x06000140 RID: 320 RVA: 0x0001C970 File Offset: 0x0001AB70
        public static CosmeticsController Con()
        {
            return CosmeticsController.instance;
        }

        // Token: 0x06000141 RID: 321 RVA: 0x0001C979 File Offset: 0x0001AB79
        public static GameObject CreatePrimitive(PrimitiveType t)
        {
            return GameObject.CreatePrimitive(t);
        }

        // Token: 0x06000113 RID: 275 RVA: 0x0001BB1F File Offset: 0x00019D1F
        public static List<VRRig> ESPPlayers()
        {
            List<VRRig> result;
            if (!CosmeticsV2Spawner_Dirty.completed)
            {
                (result = new List<VRRig>()).Add(Mods.OwnRig());
            }
            else
            {
                result = Mods.GetAllRigs(false);
            }
            return result;
        }


        // Token: 0x060000B1 RID: 177 RVA: 0x00005DA8 File Offset: 0x00003FA8
        public static void flushrpcs()
        {
            GorillaNot.instance.rpcCallLimit = int.MaxValue;
            PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
            PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
            PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig.GetView);
            PhotonNetwork.RemoveBufferedRPCs(GorillaTagger.Instance.myVRRig.ViewID, null, null);
        }

        public static void upanddown()
        {
            if (ControllerInputPoller.instance.rightControllerTriggerButton)
            {
                GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, -50f, 0f), ForceMode.Acceleration);
            }

            if (ControllerInputPoller.instance.leftControllerTriggerButton)
            {
                GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 50f, 0f), ForceMode.Acceleration);
            }
        }

        public static void Grabrig()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                VRRig.LocalRig.enabled = false;

                VRRig.LocalRig.transform.position = GorillaTagger.Instance.rightHandTransform.position;

            }
            if (ControllerInputPoller.instance.leftGrab)
            {
                VRRig.LocalRig.enabled = false;

                VRRig.LocalRig.transform.position = GorillaTagger.Instance.leftHandTransform.position;

            }

            else
            {
                VRRig.LocalRig.enabled = true;
            }
        }


            private static bool triggeredRecently = false;
            private static float lastTriggerTime = 0f;
            private static readonly float cooldown = 5f; // seconds

            public static void AntiReport()
            {
                if (triggeredRecently && Time.time - lastTriggerTime < cooldown)
                    return;

                var localPlayer = NetworkSystem.Instance.LocalPlayer;
                var scoreboardLines = GorillaScoreboardTotalUpdater.allScoreboardLines;
                var rigs = GorillaParent.instance.vrrigs;
                var offlineRig = GorillaTagger.Instance.offlineVRRig;

                foreach (var line in scoreboardLines)
                {
                    if (line.linePlayer != localPlayer)
                        continue;

                    Transform reportButtonTransform = line.reportButton.gameObject.transform;

                    foreach (var rig in rigs)
                    {
                        if (rig == offlineRig)
                            continue;

                        bool rightHandClose = Vector3.Distance(rig.rightHandTransform.position, reportButtonTransform.position) < 0.35f;
                        bool leftHandClose = Vector3.Distance(rig.leftHandTransform.position, reportButtonTransform.position) < 0.35f;

                        if (rightHandClose || leftHandClose)
                        {
                            PhotonNetwork.Disconnect();
                            NotifiLib.SendNotification("<color=grey>[</color><color=red>Someone Tried To Report You</color>");
                            triggeredRecently = true;
                            lastTriggerTime = Time.time;
                            return;
                        }
                    }
                }

                // reset the flag if enough time has passed
                if (triggeredRecently && Time.time - lastTriggerTime >= cooldown)
                    triggeredRecently = false;
            }

        // Token: 0x06000050 RID: 80 RVA: 0x0000CE20 File Offset: 0x0000B020
        public static void ShowIdGun()
        {
            Mods.MakeGun(Mods.CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, 0, GTPlayer.Instance.rightControllerTransform, true, delegate
            {
                bool flag = RigShit.GetPlayerFromGun() != null;
                if (flag)
                {
                    NotifiLib.ClearPastNotifications(1);
                    NotifiLib.SendNotification(RigShit.GetPlayerFromGun().UserId);
                }
            }, delegate
            {
            });
        }

        private static GameObject pointer6;

        public static void ShowIdGunV2()
        {
            if (!ControllerInputPoller.instance.rightGrab)
            {
                if (pointer6 != null) GameObject.Destroy(pointer6);
                GorillaTagger.Instance.offlineVRRig.enabled = true;
                return;
            }

            // create once
            if (pointer6 == null)
            {
                pointer6 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                pointer6.transform.localScale = Vector3.one * 0.2f;
                pointer6.GetComponent<Renderer>().material.color = Color.blue;
                GameObject.Destroy(pointer6.GetComponent<Collider>());
            }

            // update sphere position
            if (Physics.Raycast(GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position,
                                -GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.up,
                                out var hit))
            {
                pointer6.transform.position = hit.point;
            }

            // if trigger pressed, constantly update rig & play splash every few frames
            if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.1f)
            {
                NotifiLib.SendNotification(RigShit.GetPlayerFromGun().UserId);
            }
        }

        // Token: 0x06000035 RID: 53 RVA: 0x00002C1B File Offset: 0x00000E1B
        public static void loudhandtaps()
        {
            GorillaTagger.Instance.handTapVolume = 1f;
        }

        // Token: 0x06000036 RID: 54 RVA: 0x00002C2D File Offset: 0x00000E2D
        public static void fixloudhandtaps()
        {
            GorillaTagger.Instance.handTapVolume = 0.5f;
        }

        // Token: 0x06000037 RID: 55 RVA: 0x00002C3F File Offset: 0x00000E3F
        public static void Rapidhandtaps()
        {
            GorillaTagger.Instance.tapCoolDown = 0.1f;
        }

        // Token: 0x06000038 RID: 56 RVA: 0x00002C51 File Offset: 0x00000E51
        public static void fixRapidhandtaps()
        {
            GorillaTagger.Instance.tapCoolDown = 1f;
        }

        // Token: 0x06000039 RID: 57 RVA: 0x00002C63 File Offset: 0x00000E63
        public static void SilentHandTaps()
        {
            GorillaTagger.Instance.handTapVolume = 0f;
        }

        // Token: 0x0600003A RID: 58 RVA: 0x00002C75 File Offset: 0x00000E75
        public static void fixSilentHandTaps()
        {
            GorillaTagger.Instance.handTapVolume = 0.5f;
        }

        public static void floormagnet()
        {
            GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, -50f, 0f), ForceMode.Acceleration);
        }
        public static void DisableNetworkTriggersMod()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
        }

        public static void EnableNetworkTriggersMod()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
        }

        public static void grabR1g()
        {
            if (ControllerInputPoller.instance.leftGrab)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.position;
                GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.rotation;
            }
            if (ControllerInputPoller.instance.rightGrab)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.rotation;
            }
            if (!ControllerInputPoller.instance.rightGrab && !ControllerInputPoller.instance.leftGrab)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }


        public static void Wateraura()
        {
            if (Mods.GetTime("Water Cooltime"))
            {
                Mods.SetTime("Water Cooltime", 0.23f);
                Vector3 randomPosition = new Vector3(UnityEngine.Random.Range(-1.5f, 1.5f), UnityEngine.Random.Range(-0.25f, 1f), UnityEngine.Random.Range(-1.5f, 1.5f));
                Quaternion randomRotation = Quaternion.Euler(UnityEngine.Random.Range(-180f, 180f), UnityEngine.Random.Range(-180f, 180f), UnityEngine.Random.Range(-180f, 180f));
                GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", RpcTarget.All, new object[]
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position + randomPosition,
                    randomRotation,
                    1f,
                    0.25f,
                    true,
                    true,
                });
                Mods.flushrpcs();
            }
        }

        public static void WaterBending()
        {
            if (ControllerInputPoller.instance.leftGrab)
            {
                if (Mods.GetTime("Water Limit"))
                {
                    Mods.SetTime("Water Limit", 0.23f);
                    GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", RpcTarget.All, new object[]
                    {
                        GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.position,
                        GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.rotation * Quaternion.Euler(10f, 70f, 0f),
                        1f,
                        0.25f,
                        true,
                        true,
                    });
                    Mods.flushrpcs();
                }
            }
            if (ControllerInputPoller.instance.rightGrab)
            {
                if (Mods.GetTime("Water Limit 2"))
                {
                    Mods.SetTime("Water Limit 2", 0.23f);
                    GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", RpcTarget.All, new object[]
                    {
                        GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position,
                        GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.rotation * Quaternion.Euler(-10f, -70f, 0f),
                        1f,
                        0.25f,
                        true,
                        true,
                    });
                    Mods.flushrpcs();
                }
            }
        }

        private static bool wait = false;

        private static GameObject pointer4;


        public static void SplashGun2()
        {
            var rightHand = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform;
            var rightGrab = ControllerInputPoller.instance.rightGrab;
            var trigger = ControllerInputPoller.instance.rightControllerIndexFloat;
            var rig = GorillaTagger.Instance.offlineVRRig;

            // Reset when not grabbing
            if (!rightGrab)
            {
                if (pointer4 != null)
                    GameObject.Destroy(pointer4);

                if (rigHidden)
                {
                    rig.enabled = true;
                    rigHidden = false;
                }
                return;
            }

            // Create pointer sphere once
            if (pointer4 == null)
            {
                pointer4 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                pointer4.transform.localScale = Vector3.one * 0.2f;
                pointer4.GetComponent<Renderer>().material.color = Color.blue;
                GameObject.Destroy(pointer4.GetComponent<Collider>());
            }

            // Start ray just in front of controller to avoid self-hit
            Vector3 start = rightHand.position + (-rightHand.up * 0.05f);
            Vector3 direction = -rightHand.up;

            // Get colliders of your rig so we can ignore them
            Collider[] selfColliders = rig.GetComponentsInChildren<Collider>();

            RaycastHit bestHit = default;
            bool foundValidHit = false;
            float closestDist = float.MaxValue;

            // 🔹 Use RaycastAll to catch *everything*, then filter manually
            foreach (var hit in Physics.RaycastAll(start, direction, 100f, ~0, QueryTriggerInteraction.Ignore))
            {
                // Ignore self colliders
                bool isSelf = false;
                foreach (var self in selfColliders)
                {
                    if (hit.collider == self)
                    {
                        isSelf = true;
                        break;
                    }
                }

                // Skip any triggers or non-solid colliders
                if (isSelf || hit.collider.isTrigger)
                    continue;

                // Choose the closest valid collider
                if (hit.distance < closestDist)
                {
                    closestDist = hit.distance;
                    bestHit = hit;
                    foundValidHit = true;
                }
            }

            // Update pointer position if we hit something
            if (foundValidHit)
            {
                pointer4.transform.position = bestHit.point;
            }

            // Handle rig behavior
            if (trigger > 0.1f && foundValidHit)
            {
                if (!rigHidden)
                {
                    rig.enabled = false;
                    rigHidden = true;
                }

                // Hover slightly above surface
                Vector3 targetPos = pointer4.transform.position + new Vector3(0f, -0.75f, 0f);

                // Smooth follow
                rig.transform.position = Vector3.Lerp(rig.transform.position, targetPos, Time.deltaTime * 10f);
                // ❌ No rotation

                Vector3 splashPos = rig.transform.position + new Vector3(0f, 0.1f, 0f); // adjust 0.1f as needed

                //add splash stuff
                if (Mods.GetTime("Water Cooltime67"))
                {
                    Mods.SetTime("Water Cooltime67", 0.23f); // faster refresh
                    GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", RpcTarget.All, new object[]
                    {
                        //make splash mods go to rig
                splashPos,
                1f,
                0.25f,
                true,
                true,
                    });

                    Mods.flushrpcs();
                }
            }
            else
            {
                if (rigHidden)
                {
                    rig.enabled = true;
                    rigHidden = false;
                }
            }
        }
        

        public static bool GetTime(string name)
        {
            timeDict.TryGetValue(name, out float val);
            if (val < Time.time)
            {
                return true;
            }
            return false;
        }

        public static void SetTime(string name, float val)
        {
            if (GetTime(name))
            {
                timeDict[name] = Time.time + val;
                return;
            }
            return;
        }

        private static Dictionary<string, float> timeDict = new Dictionary<string, float>();

        #endregion
        #region Rig Mods
        public static void Ghostmonke()
        {
            if (right)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = !ghostMonke;
                if (ghostMonke)
                {
                    DrawHandOrbs();
                }
                if (WristMenu.ybuttonDown && !lastHit)
                {
                    ghostMonke = !ghostMonke;
                }
                lastHit = WristMenu.ybuttonDown;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = !ghostMonke;
                if (ghostMonke)
                {
                    DrawHandOrbs();
                }
                if (WristMenu.bbuttonDown && !lastHit)
                {
                    ghostMonke = !ghostMonke;
                }
                lastHit = WristMenu.bbuttonDown;
            }
        }
        public static void Invis()
        {
            if (right)
            {
                if (invisMonke)
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(9999f, 9999f, 9999f);
                    DrawHandOrbs();
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
                if (WristMenu.ybuttonDown && !lastHit2)
                {
                    invisMonke = !invisMonke;
                }
                lastHit2 = WristMenu.ybuttonDown;
            }
            else
            {
                if (invisMonke)
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(9999f, 9999f, 9999f);
                    DrawHandOrbs();
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
                if (WristMenu.bbuttonDown && !lastHit2)
                {
                    invisMonke = !invisMonke;
                }
                lastHit2 = WristMenu.bbuttonDown;
            }
        }

        public static void SpazHead()
        {
            if (VRRig.LocalRig.enabled)
            {
                VRRig.LocalRig.head.trackingRotationOffset.x = UnityEngine.Random.Range(0f, 360f);
                VRRig.LocalRig.head.trackingRotationOffset.y = UnityEngine.Random.Range(0f, 360f);
                VRRig.LocalRig.head.trackingRotationOffset.z = UnityEngine.Random.Range(0f, 360f);
            }
            else
            {

                VRRig.LocalRig.head.trackingRotationOffset.x = UnityEngine.Random.Range(0f, 0f);
                VRRig.LocalRig.head.trackingRotationOffset.y = UnityEngine.Random.Range(0f, 0f);
                VRRig.LocalRig.head.trackingRotationOffset.z = UnityEngine.Random.Range(0f, 0f);

            }
        }
        public static void FixHead()
        {
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0f;
        }

        public static void grabrig()
        {
                if (ControllerInputPoller.instance.rightGrab)
                {
                    DrawHandOrbs();
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                }

                if (ControllerInputPoller.instance.leftGrab)
                {
                    DrawHandOrbs();
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.position;
                }

                else
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }



        public static void NoHandMovement() //basically disables your fingers
        {
            ControllerInputPoller.instance.leftControllerGripFloat = 0f;
            ControllerInputPoller.instance.rightControllerGripFloat = 0f;
            ControllerInputPoller.instance.leftControllerIndexFloat = 0f;
            ControllerInputPoller.instance.rightControllerIndexFloat = 0f;
            ControllerInputPoller.instance.leftControllerPrimaryButton = false;
            ControllerInputPoller.instance.leftControllerSecondaryButton = false;
            ControllerInputPoller.instance.rightControllerPrimaryButton = false;
            ControllerInputPoller.instance.rightControllerSecondaryButton = false;
            ControllerInputPoller.instance.leftControllerPrimaryButtonTouch = false;
            ControllerInputPoller.instance.leftControllerSecondaryButtonTouch = false;
            ControllerInputPoller.instance.rightControllerPrimaryButtonTouch = false;
            ControllerInputPoller.instance.rightControllerSecondaryButtonTouch = false;
        }

        public static void DisableNetworkTriggers()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
        }
        public static void EnableNetworkTriggers()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
        }

        
        public static void TpGun()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                Physics.Raycast(GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position, -GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.up, out var hitInfo);
                pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                pointer.GetComponent<Renderer>().material.color = Color.blue ;
                pointer.transform.position = hitInfo.point;
                GameObject.Destroy(pointer.GetComponent<BoxCollider>());
                GameObject.Destroy(pointer.GetComponent<Rigidbody>());
                GameObject.Destroy(pointer.GetComponent<Collider>());
                if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.1)
                {
                    GameObject.Destroy(pointer, Time.deltaTime);
                    if (!wait)
                    {
                        wait = true;
                        GorillaLocomotion.GTPlayer.Instance.transform.position = pointer.transform.position;
                        GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().linearVelocity = pointer.transform.position;
                    }
                }
                else
                {
                    wait = false;
                }

                if (pointer != null)
                {
                    GameObject.Destroy(pointer, Time.deltaTime);
                }

            }
    }    // made by TRMbilly


        public static void TeleportGun()
        {
            GunLib.UpdateGun(
                onShoot: (pos, hit) =>
                {
                    var player = GorillaLocomotion.GTPlayer.Instance;

                    // Instantly teleport player
                    player.transform.position = pos + Vector3.up * 0.1f;

                    // Stop any movement after teleport
                    var rb = player.GetComponent<Rigidbody>();
                    if (rb != null)
                        rb.velocity = Vector3.zero;
                },
                onRelease: () =>
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            );
        }

        public static class GunLib
        {
            private static GameObject pointer;
            private static bool isAiming;
            private static float shootCooldown;

            /// <summary>
            /// Call this every frame (e.g., inside Update)
            /// </summary>
            /// <param name="onShoot">Action when trigger is pressed</param>
            /// <param name="onHold">Action while trigger is held</param>
            /// <param name="onRelease">Action when trigger is released</param>
            public static void UpdateGun(System.Action<Vector3, RaycastHit> onShoot = null,
                                         System.Action<Vector3, RaycastHit> onHold = null,
                                         System.Action onRelease = null)
            {
                var rightHand = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform;
                var rightGrab = ControllerInputPoller.instance.rightGrab;
                var trigger = ControllerInputPoller.instance.rightControllerIndexFloat;
                var rig = GorillaTagger.Instance.offlineVRRig;

                // Handle idle state (not grabbing)
                if (!rightGrab)
                {
                    Cleanup();
                    return;
                }

                // Create pointer sphere if not present
                if (pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    pointer.transform.localScale = Vector3.one * 0.2f;
                    pointer.GetComponent<Renderer>().material.color = Color.blue;
                    GameObject.Destroy(pointer.GetComponent<Collider>());
                }

                // Raycast setup
                Vector3 start = rightHand.position + (-rightHand.up * 0.05f);
                Vector3 direction = -rightHand.up;
                Collider[] selfCols = rig.GetComponentsInChildren<Collider>();

                RaycastHit bestHit;
                bool validHit = TryGetSurfaceHit(start, direction, selfCols, out bestHit);

                // Update pointer position
                if (validHit)
                    pointer.transform.position = bestHit.point;

                // Check trigger input
                bool triggerDown = trigger > 0.1f;
                bool canShoot = Time.time > shootCooldown;

                if (triggerDown)
                {
                    if (!isAiming)
                    {
                        isAiming = true;
                        shootCooldown = Time.time + 0.2f; // small delay
                        onShoot?.Invoke(pointer.transform.position, bestHit);
                    }

                    onHold?.Invoke(pointer.transform.position, bestHit);
                }
                else if (isAiming)
                {
                    isAiming = false;
                    onRelease?.Invoke();
                }
            }

            private static void Cleanup()
            {
                if (pointer != null)
                    GameObject.Destroy(pointer);

                isAiming = false;
            }

            /// <summary>
            /// Smart raycast that ignores your rig & non-physical triggers.
            /// </summary>
            private static bool TryGetSurfaceHit(Vector3 start, Vector3 dir, Collider[] selfCols, out RaycastHit best)
            {
                best = default;
                float closest = float.MaxValue;
                bool found = false;

                foreach (var hit in Physics.RaycastAll(start, dir, 100f, ~0, QueryTriggerInteraction.Ignore))
                {
                    if (hit.collider.isTrigger) continue;

                    bool isSelf = false;
                    foreach (var self in selfCols)
                        if (hit.collider == self) { isSelf = true; break; }

                    if (isSelf) continue;

                    if (hit.distance < closest)
                    {
                        closest = hit.distance;
                        best = hit;
                        found = true;
                    }
                }

                return found;
            }
        }

        #endregion
        #region Visual
        public static void Tracers()
        {
            foreach (Player p in PhotonNetwork.PlayerListOthers)
            {
                VRRig rig = RigShit.GetVRRigFromPlayer(p);
                GameObject g = new GameObject("Line");
                LineRenderer l = g.AddComponent<LineRenderer>();
                l.startWidth = 0.01f;
                l.endWidth = 0.01f;
                l.positionCount = 2;
                l.useWorldSpace = true;
                l.SetPosition(0, GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position);
                l.SetPosition(1, rig.transform.position);
                l.material.shader = Shader.Find("GUI/Text Shader");
                l.startColor = CurrentESPColor;
                l.endColor = CurrentESPColor;
                Destroy(l, Time.deltaTime);
            }
        }

        public static void BoxESP()
        {

            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                {
                    UnityEngine.Color thecolor = vrrig.playerColor;
                    GameObject box = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    box.transform.position = vrrig.transform.position;
                    UnityEngine.Object.Destroy(box.GetComponent<BoxCollider>());
                    box.transform.localScale = new Vector3(0.5f, 0.5f, 0f);
                    box.transform.LookAt(GorillaTagger.Instance.headCollider.transform.position);
                    box.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    box.GetComponent<Renderer>().material.color = thecolor;
                    UnityEngine.Object.Destroy(box, Time.deltaTime);
                }
            }
        }

        // Token: 0x0600009E RID: 158 RVA: 0x000137F0 File Offset: 0x000119F0
        public static void BoxESPV2()
        {
            foreach (VRRig vrrig in Mods.ESPPlayers())
            {
                Shader esp = Shader.Find("GUI/Text Shader");
                Color color = CurrentESPColor;
                PrimitiveType primitiveType = PrimitiveType.Cube;
                GameObject gameObject = Mods.CreatePrimitive(primitiveType);
                Transform transform = gameObject.transform;
                UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject.GetComponent<Renderer>());
                transform.position = vrrig.transform.position;
                GameObject gameObject2 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject3 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject4 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject5 = Mods.CreatePrimitive(primitiveType);
                UnityEngine.Object.Destroy(gameObject2.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject5.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject4.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject3.GetComponent<BoxCollider>());
                gameObject2.transform.SetParent(transform);
                gameObject5.transform.SetParent(transform);
                gameObject4.transform.SetParent(transform);
                gameObject3.transform.SetParent(transform);
                gameObject2.transform.localPosition = new Vector3(0f, 0.49f, 0f);
                gameObject5.transform.localPosition = new Vector3(0f, -0.49f, 0f);
                gameObject4.transform.localPosition = new Vector3(-0.49f, 0f, 0f);
                gameObject3.transform.localPosition = new Vector3(0.49f, 0f, 0f);
                gameObject2.transform.localScale = new Vector3(1f, 0.02f, 0.02f);
                gameObject5.transform.localScale = new Vector3(1f, 0.02f, 0.02f);
                gameObject4.transform.localScale = new Vector3(0.02f, 1f, 0.02f);
                gameObject3.transform.localScale = new Vector3(0.02f, 1f, 0.02f);
                gameObject2.GetComponent<Renderer>().material.shader = esp;
                gameObject5.GetComponent<Renderer>().material.shader = esp;
                gameObject4.GetComponent<Renderer>().material.shader = esp;
                gameObject3.GetComponent<Renderer>().material.shader = esp;
                gameObject2.GetComponent<Renderer>().material.color = color;
                gameObject3.GetComponent<Renderer>().material.color = color;
                gameObject4.GetComponent<Renderer>().material.color = color;
                gameObject5.GetComponent<Renderer>().material.color = color;
                transform.LookAt(Camera.main.transform.position);
                UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
            }
        }

        // Token: 0x0600009F RID: 159 RVA: 0x00013AFC File Offset: 0x00011CFC
        public static void BoxESPV3()
        {
            foreach (VRRig vrrig in Mods.ESPPlayers())
            {
                Shader esp = Shader.Find("GUI/Text Shader");
                Color color = CurrentESPColor;
                PrimitiveType primitiveType = PrimitiveType.Cube;
                GameObject gameObject = Mods.CreatePrimitive(primitiveType);
                Transform transform = gameObject.transform;
                UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject.GetComponent<Renderer>());
                transform.position = vrrig.transform.position;
                GameObject gameObject2 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject3 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject4 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject5 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject6 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject7 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject8 = Mods.CreatePrimitive(primitiveType);
                GameObject gameObject9 = Mods.CreatePrimitive(primitiveType);
                UnityEngine.Object.Destroy(gameObject2.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject5.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject4.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject3.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject6.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject7.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject8.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(gameObject9.GetComponent<BoxCollider>());
                gameObject2.transform.SetParent(transform);
                gameObject5.transform.SetParent(transform);
                gameObject4.transform.SetParent(transform);
                gameObject3.transform.SetParent(transform);
                gameObject6.transform.SetParent(transform);
                gameObject7.transform.SetParent(transform);
                gameObject8.transform.SetParent(transform);
                gameObject9.transform.SetParent(transform);
                gameObject2.transform.localPosition = new Vector3(-0.42f, 0.49f, 0f);
                gameObject4.transform.localPosition = new Vector3(-0.49f, 0.42f, 0f);
                gameObject5.transform.localPosition = new Vector3(0.42f, 0.49f, 0f);
                gameObject3.transform.localPosition = new Vector3(0.49f, 0.42f, 0f);
                gameObject6.transform.localPosition = new Vector3(-0.42f, -0.49f, 0f);
                gameObject7.transform.localPosition = new Vector3(-0.49f, -0.42f, 0f);
                gameObject8.transform.localPosition = new Vector3(0.42f, -0.49f, 0f);
                gameObject9.transform.localPosition = new Vector3(0.49f, -0.42f, 0f);
                gameObject2.transform.localScale = new Vector3(0.15f, 0.02f, 0.02f);
                gameObject5.transform.localScale = new Vector3(0.15f, 0.02f, 0.02f);
                gameObject4.transform.localScale = new Vector3(0.02f, 0.15f, 0.02f);
                gameObject3.transform.localScale = new Vector3(0.02f, 0.15f, 0.02f);
                gameObject6.transform.localScale = new Vector3(0.15f, 0.02f, 0.02f);
                gameObject7.transform.localScale = new Vector3(0.02f, 0.15f, 0.02f);
                gameObject8.transform.localScale = new Vector3(0.15f, 0.02f, 0.02f);
                gameObject9.transform.localScale = new Vector3(0.02f, 0.15f, 0.02f);
                gameObject2.GetComponent<Renderer>().material.shader = esp;
                gameObject5.GetComponent<Renderer>().material.shader = esp;
                gameObject4.GetComponent<Renderer>().material.shader = esp;
                gameObject3.GetComponent<Renderer>().material.shader = esp;
                gameObject6.GetComponent<Renderer>().material.shader = esp;
                gameObject7.GetComponent<Renderer>().material.shader = esp;
                gameObject8.GetComponent<Renderer>().material.shader = esp;
                gameObject9.GetComponent<Renderer>().material.shader = esp;
                gameObject2.GetComponent<Renderer>().material.color = color;
                gameObject3.GetComponent<Renderer>().material.color = color;
                gameObject4.GetComponent<Renderer>().material.color = color;
                gameObject5.GetComponent<Renderer>().material.color = color;
                gameObject6.GetComponent<Renderer>().material.color = color;
                gameObject7.GetComponent<Renderer>().material.color = color;
                gameObject8.GetComponent<Renderer>().material.color = color;
                gameObject9.GetComponent<Renderer>().material.color = color;
                transform.LookAt(Camera.main.transform.position);
                UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
            }
        }

        public static bool esp;
        public static void EnableAllChams()
        {
            esp = true; // makes esp true
            if (esp)
            {
                foreach (VRRig rig in GorillaParent.instance.vrrigs)
                {
                    if (!rig.isOfflineVRRig)
                    {
                        rig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                        rig.mainSkin.material.color = Color.blue; // color u want the player to be
                    }
                }
            }
        }
        // disable chams
        public static void DisableAllChams()
        {
            if (esp) // checks if esp is on
            {
                foreach (VRRig rig in GorillaParent.instance.vrrigs)
                {
                    if (!rig.isOfflineVRRig)
                    {
                        rig.mainSkin.material.shader = Shader.Find("GorillaTag/UberShade"); // disables esp
                    }
                }
                esp = false; // makes it so it stops disabling chams
            }
        }

        // Token: 0x0600006D RID: 109 RVA: 0x00011AB4 File Offset: 0x0000FCB4
        public static void LongArms()
        {
            Mods.longArms = true;
            Mods.Arm(1.09f);
        }

        // Token: 0x0600006E RID: 110 RVA: 0x00011AC8 File Offset: 0x0000FCC8
        public static void Resetarms()
        {
            bool flag = Mods.longArms;
            if (flag)
            {
                Mods.Arm(1f);
                Mods.longArms = false;
            }
        }

        // Token: 0x0600006F RID: 111 RVA: 0x00011AF2 File Offset: 0x0000FCF2
        public static void LongerArms()
        {
            Mods.longgArms = true;
            Mods.Arm(1.2f);
        }

        public static void Resetarms1()
        {
            bool flag = Mods.longgArms;
            if (flag)
            {
                Mods.Arm(1f);
                Mods.longgArms = false;
            }
        }

        // Token: 0x06000071 RID: 113 RVA: 0x00011B32 File Offset: 0x0000FD32
        public static void LongererArms()
        {
            Mods.longggArms = true;
            Mods.Arm(1.6f);
        }

        // Token: 0x06000072 RID: 114 RVA: 0x00011B48 File Offset: 0x0000FD48
        public static void Resetarms2()
        {
            bool flag = Mods.longggArms;
            if (flag)
            {
                Mods.Arm(1f);
                Mods.longggArms = false;
            }
        }

        // Token: 0x06000134 RID: 308 RVA: 0x0001C6CC File Offset: 0x0001A8CC
        public static void Arm(float l)
        {
            Mods.Loco().transform.localScale = new Vector3(l, l, l);
        }

        // Token: 0x06000088 RID: 136 RVA: 0x0001260C File Offset: 0x0001080C
        // Token: 0x040000D2 RID: 210
        public static bool longArms;

        // Token: 0x040000D3 RID: 211
        public static bool longgArms;

        // Token: 0x040000D4 RID: 212
        public static bool longggArms;

        public static void BoneESPself()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                // Remove the check that skips offline rigs — we want all rigs (including local)
                LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(vrrig.head.rigTarget.gameObject);
                orAddComponent.startWidth = 0.015f;
                orAddComponent.endWidth = 0.015f;
                orAddComponent.startColor = CurrentESPColor;
                orAddComponent.endColor = CurrentESPColor;
                orAddComponent.material.shader = Shader.Find("GUI/Text Shader");
                orAddComponent.SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
                orAddComponent.SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));

                for (int i = 0; i < bones.Length; i += 2)
                {
                    LineRenderer orAddComponent2 = GTExt.GetOrAddComponent<LineRenderer>(vrrig.mainSkin.bones[bones[i]].gameObject);
                    orAddComponent2.startWidth = 0.015f;
                    orAddComponent2.endWidth = 0.015f;
                    orAddComponent2.startColor = CurrentESPColor;
                    orAddComponent2.endColor = CurrentESPColor;
                    orAddComponent2.material.shader = Shader.Find("GUI/Text Shader");
                    orAddComponent2.SetPosition(0, vrrig.mainSkin.bones[bones[i]].position);
                    orAddComponent2.SetPosition(1, vrrig.mainSkin.bones[bones[i + 1]].position);
                }
            }
        }

        public static void BoneESPselfOff()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                LineRenderer component = vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>();
                if (component != null)
                    UnityEngine.Object.Destroy(component);

                for (int i = 0; i < bones.Length; i += 2)
                {
                    LineRenderer component2 = vrrig.mainSkin.bones[bones[i]].gameObject.GetComponent<LineRenderer>();
                    if (component2 != null)
                        UnityEngine.Object.Destroy(component2);
                }
            }
        }
        public static void BoneESP()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = !vrrig.isOfflineVRRig;
                if (flag)
                {
                    LineRenderer orAddComponent = GTExt.GetOrAddComponent<LineRenderer>(vrrig.head.rigTarget.gameObject);
                    orAddComponent.startWidth = 0.015f;
                    orAddComponent.endWidth = 0.015f;
                    orAddComponent.startColor = CurrentESPColor;
                    orAddComponent.endColor = CurrentESPColor;
                    orAddComponent.material.shader = Shader.Find("GUI/Text Shader");
                    orAddComponent.SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
                    orAddComponent.SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
                    for (int i = 0; i < bones.Count<int>(); i += 2)
                    {
                        LineRenderer orAddComponent2 = GTExt.GetOrAddComponent<LineRenderer>(vrrig.mainSkin.bones[bones[i]].gameObject);
                        orAddComponent2.startWidth = 0.015f;
                        orAddComponent2.endWidth = 0.015f;
                        orAddComponent2.startColor = CurrentESPColor;
                        orAddComponent2.endColor = CurrentESPColor;
                        orAddComponent2.material.shader = Shader.Find("GUI/Text Shader");
                        orAddComponent2.SetPosition(0, vrrig.mainSkin.bones[bones[i]].position);
                        orAddComponent2.SetPosition(1, vrrig.mainSkin.bones[bones[i + 1]].position);
                    }
                }
            }
        }

        public static void BoneESPOff()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = !vrrig.isOfflineVRRig;
                if (flag)
                {
                    LineRenderer component = vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>();
                    bool flag2 = component != null;
                    if (flag2)
                    {
                        UnityEngine.Object.Destroy(component);
                    }
                    for (int i = 0; i < bones.Count<int>(); i += 2)
                    {
                        LineRenderer component2 = vrrig.mainSkin.bones[bones[i]].gameObject.GetComponent<LineRenderer>();
                        bool flag3 = component2 != null;
                        if (flag3)
                        {
                            UnityEngine.Object.Destroy(component2);
                        }
                    }
                }
            }
        }
        // Token: 0x04000034 RID: 52
        public static int[] bones = new int[]
        {
    4,
    3,
    5,
    4,
    19,
    18,
    20,
    19,
    3,
    18,
    21,
    20,
    22,
    21,
    25,
    21,
    29,
    21,
    31,
    29,
    27,
    25,
    24,
    22,
    6,
    5,
    7,
    6,
    10,
    6,
    14,
    6,
    16,
    14,
    12,
    10,
    9,
    7
        };

        public static Color32 BgColor1 = new Color32(6, 6, 6, byte.MaxValue);

        public static Color32 BgColor2 = new Color32(14, 14, 14, byte.MaxValue);

        public static void SphereESP()
        {
            foreach (VRRig vrrig in Mods.ESPPlayers())
            {
                GameObject gameObject = Mods.CreatePrimitive(0);
                gameObject.transform.position = vrrig.transform.position;
                UnityEngine.Object.Destroy(gameObject.GetComponent<SphereCollider>());
                gameObject.transform.localScale = new Vector3(0.25f, 0.25f, 0.25f);
                gameObject.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                gameObject.GetComponent<Renderer>().material.color = CurrentESPColor;
                UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
            }
        }

        // Token: 0x0600008A RID: 138 RVA: 0x0001282C File Offset: 0x00010A2C
        public static void WallWalk()
        {
            bool wallTouched = false;

            // --- Right Hand ---
            if (WristMenu.gripDownR)
            {
                RaycastHit hitR;
                if (Physics.Raycast(
                        Mods.Loco().rightControllerTransform.position,
                        -Mods.Loco().rightControllerTransform.up,
                        out hitR, 3f))
                {
                    Mods.Grav(0f);
                    Mods.Loco().bodyCollider.attachedRigidbody.linearVelocity -=
                        hitR.normal * (Mods.Walk * Time.deltaTime);
                    wallTouched = true;
                }
            }

            // --- Left Hand ---
            if (WristMenu.gripDownL)
            {
                RaycastHit hitL;
                if (Physics.Raycast(
                        Mods.Loco().leftControllerTransform.position,
                        -Mods.Loco().leftControllerTransform.up,
                        out hitL, 3f))
                {
                    Mods.Grav(0f);
                    Mods.Loco().bodyCollider.attachedRigidbody.linearVelocity -=
                        hitL.normal * (Mods.Walk * Time.deltaTime);
                    wallTouched = true;
                }
            }

            // --- Restore gravity if not touching any wall ---
            if (!wallTouched)
            {
                Mods.Grav(-9.81f);
            }
            //fixed up by chatgpt lmao skidded from malachi menu
        }


        // Token: 0x04000107 RID: 263
        public static float Walk = 10f;
        public static void Grav(float g)
        {
            Physics.gravity = new Vector3(0f, g, 0f);
        }

        // Token: 0x06000083 RID: 131 RVA: 0x000121A4 File Offset: 0x000103A4
        public static void VelFly()
        {
            bool abuttonDown = WristMenu.abuttonDown;
            if (abuttonDown)
            {
                Mods.Loco().GetComponent<Rigidbody>().linearVelocity += Mods.Loco().headCollider.transform.forward * Time.deltaTime * 40f;
            }
        }

        // Token: 0x06000133 RID: 307 RVA: 0x0001C6BF File Offset: 0x0001A8BF
        public static void Speed(float speed)
        {
            Mods.Loco().maxJumpSpeed = speed;
        }


        // Token: 0x06000086 RID: 134 RVA: 0x000122BC File Offset: 0x000104BC
        public static void FastSwim()
        {
            bool inWater = Mods.Loco().InWater;
            if (inWater)
            {
                Mods.Loco().gameObject.GetComponent<Rigidbody>().linearVelocity *= 1.04f;
            }
        }

        // Token: 0x060000BD RID: 189 RVA: 0x000164EC File Offset: 0x000146EC
        public static void GetAllIDs()
        {
            string text = string.Concat(new string[]
            {
        "IDS GRABBED FROM ",
        WristMenu.MenuTitle.ToUpper(),
        "\nJOIN DISCORD.GG/JPZxC6Mkf6\nIDS FROM ROOM: ",
        PhotonNetwork.CurrentRoom.Name,
        "\n\n"
            });
            foreach (Player player in Mods.GetAllPlayers(true))
            {
                Color playerColor = RigShit.GetVRRigFromPlayer(player).playerColor;
                text = string.Concat(new string[]
                {
            text,
            "NAME: ",
            player.NickName,
            " | ID: ",
            player.UserId,
            " | COLOR CODE: ",
            Mathf.RoundToInt(playerColor.r * 9f).ToString(),
            Mathf.RoundToInt(playerColor.g * 9f).ToString(),
            Mathf.RoundToInt(playerColor.b * 9f).ToString(),
            " / ",
            Mathf.RoundToInt(playerColor.r * 255f).ToString(),
            ", ",
            Mathf.RoundToInt(playerColor.g * 255f).ToString(),
            ", ",
            Mathf.RoundToInt(playerColor.b * 255f).ToString(),
            "\n"
                });
            }
            Directory.CreateDirectory("SkidMenu");
            File.WriteAllText("SkidMenu/Player_IDS.txt", text);
            Process.Start("notepad.exe", "SkidMenu/Player_IDS.txt");
            Mods.DisableButton("Get All IDS");
        }

        public static GameObject draw;
        public static void DrawMod()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat == 1f)
            {
                draw = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                draw.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                Renderer drawren = draw.GetComponent<Renderer>();
                drawren.material.color = Color.white;
                draw.transform.position = GorillaTagger.Instance.rightHandTransform.transform.position;
            }

        }

        public static GameObject draw2;
        private static List<GameObject> drawnObjects = new List<GameObject>();

        public static void DrawMod2()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat == 1f)
            {
                // Create a sphere for drawing
                draw2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                draw2.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);

                // Remove collision
                Collider col = draw2.GetComponent<Collider>();
                if (col != null)
                    GameObject.Destroy(col);

                // Set color and position
                Renderer drawren = draw2.GetComponent<Renderer>();
                drawren.material.color = Color.blue;
                draw2.transform.position = GorillaTagger.Instance.rightHandTransform.transform.position;

                // Store reference so we can delete later
                drawnObjects.Add(draw2);
            }

            RPCProtection();
        }

        public static void delete2()
        {
            foreach (var obj in drawnObjects)
            {
                if (obj != null)
                    GameObject.Destroy(obj);
            }
            drawnObjects.Clear();

            RPCProtection();
        }
        public static void RPCProtection()
        {
            try
            {
                if (false == false)
                {
                    if (false)
                    {
                        RaiseEventOptions options = new RaiseEventOptions();
                        options.CachingOption = EventCaching.RemoveFromRoomCache;
                        options.TargetActors = new int[1] { PhotonNetwork.LocalPlayer.ActorNumber };
                        PhotonNetwork.NetworkingClient.OpRaiseEvent(200, null, options, SendOptions.SendReliable);
                    }
                    else
                    {
                        GorillaNot.instance.rpcErrorMax = int.MaxValue;
                        GorillaNot.instance.rpcCallLimit = int.MaxValue;
                        GorillaNot.instance.logErrorMax = int.MaxValue;

                        PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
                        PhotonNetwork.QuickResends = int.MaxValue;

                        //PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig.GetView);
                        PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
                        PhotonNetwork.SendAllOutgoingCommands();

                        GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
                    }
                }
            }
            catch { UnityEngine.Debug.Log("RPC protection failed, are you in a lobby?"); }
        }

        public static GameObject BlobM3;
        private static List<GameObject> drawnObjects2 = new List<GameObject>();
        public static void OrbShooter()
        {
            if (ControllerInputPoller.instance.rightGrab)
                BlobM3 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            BlobM3.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
            BlobM3.transform.position = GorillaTagger.Instance.rightHandTransform.position;
            Renderer renderer = BlobM3.GetComponent<Renderer>();
            renderer.material.color = Color.magenta;
            Rigidbody rb = BlobM3.AddComponent<Rigidbody>();
            rb.useGravity = true;
            rb.mass = 1f;
            float launchForce = 45f;
            rb.velocity = GorillaTagger.Instance.rightHandTransform.transform.forward * launchForce;

            // Store reference so we can delete later
            drawnObjects2.Add(BlobM3);

            RPCProtection();

        }

        public static void delete3()
        {
            foreach (var obj in drawnObjects2)
            {
                if (obj != null)
                    GameObject.Destroy(obj);
            }
            drawnObjects2.Clear();

            RPCProtection();
        }

        // this example is for when u want to execute code when holding ur trigger and when ur not holding trigger
        public static void riggun() // this mod is a rig gun
        {
            MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, PrimitiveType.Sphere, GorillaLocomotion.GTPlayer.Instance.rightControllerTransform, true, delegate
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = pointer.transform.position + new Vector3(0f, 0.3f, 0f);
            }, delegate { GorillaTagger.Instance.offlineVRRig.enabled = true; }); // this code makes ur rig go back to normal if ur not holding ur trigger
        }

        private static GameObject pointer3;
        private static bool rigHidden = false;

        public static void riggunv2()
        {
            var rightHand = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform;
            var rightGrab = ControllerInputPoller.instance.rightGrab;
            var trigger = ControllerInputPoller.instance.rightControllerIndexFloat;
            var rig = GorillaTagger.Instance.offlineVRRig;

            // Reset when not grabbing
            if (!rightGrab)
            {
                if (pointer3 != null)
                    GameObject.Destroy(pointer3);

                if (rigHidden)
                {
                    rig.enabled = true;
                    rigHidden = false;
                }
                return;
            }

            // Create pointer sphere once
            if (pointer3 == null)
            {
                pointer3 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                pointer3.transform.localScale = Vector3.one * 0.2f;
                pointer3.GetComponent<Renderer>().material.color = Color.blue;
                GameObject.Destroy(pointer3.GetComponent<Collider>());
            }

            // Start ray just in front of controller to avoid self-hit
            Vector3 start = rightHand.position + (-rightHand.up * 0.05f);
            Vector3 direction = -rightHand.up;

            // Get colliders of your rig so we can ignore them
            Collider[] selfColliders = rig.GetComponentsInChildren<Collider>();

            RaycastHit bestHit = default;
            bool foundValidHit = false;
            float closestDist = float.MaxValue;

            // 🔹 Use RaycastAll to catch *everything*, then filter manually
            foreach (var hit in Physics.RaycastAll(start, direction, 100f, ~0, QueryTriggerInteraction.Ignore))
            {
                // Ignore self colliders
                bool isSelf = false;
                foreach (var self in selfColliders)
                {
                    if (hit.collider == self)
                    {
                        isSelf = true;
                        break;
                    }
                }

                // Skip any triggers or non-solid colliders
                if (isSelf || hit.collider.isTrigger)
                    continue;

                // Choose the closest valid collider
                if (hit.distance < closestDist)
                {
                    closestDist = hit.distance;
                    bestHit = hit;
                    foundValidHit = true;
                }
            }

            // Update pointer position if we hit something
            if (foundValidHit)
            {
                pointer3.transform.position = bestHit.point;
            }

            // Handle rig behavior
            if (trigger > 0.1f && foundValidHit)
            {
                if (!rigHidden)
                {
                    rig.enabled = false;
                    rigHidden = true;
                }

                // Hover slightly above surface
                Vector3 targetPos = pointer3.transform.position + new Vector3(0f, 0.75f, 0f);

                // Smooth follow
                rig.transform.position = Vector3.Lerp(rig.transform.position, targetPos, Time.deltaTime * 10f);
                // ❌ No rotation
            }
            else
            {
                if (rigHidden)
                {
                    rig.enabled = true;
                    rigHidden = false;
                }
            }
        }

        public static void buggun() // this mod is a bug gun
        {
            MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, PrimitiveType.Sphere, GorillaLocomotion.GTPlayer.Instance.rightControllerTransform, true, delegate
            {
                GameObject.Find("Floating Bug Holdable").transform.position = pointer.transform.position + new Vector3(0f, 0.25f, 0f);
            }, delegate { });
        }
        public static void batgun() // this mod is a bug gun
        {
            MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, PrimitiveType.Sphere, GorillaLocomotion.GTPlayer.Instance.rightControllerTransform, true, delegate
            {
                GameObject.Find("Cave Bat Holdable").transform.position = pointer.transform.position + new Vector3(0f, 0.25f, 0f);
            }, delegate { });
        }

        public static void buggunV2()
        {
            GunLib.UpdateGun(
                onShoot: (pos, hit) =>
                {
                    GameObject bug = GameObject.Find("Floating Bug Holdable");
                    if (bug != null)
                    {
                        bug.transform.position = pos + new Vector3(0f, 0.25f, 0f);
                    }
                }
            );
        }

        public static void batgunV2()
        {
            GunLib.UpdateGun(
                onShoot: (pos, hit) =>
                {
                    GameObject bat = GameObject.Find("Cave Bat Holdable");
                    if (bat != null)
                    {
                        bat.transform.position = pos + new Vector3(0f, 0.25f, 0f);
                    }
                }
            );
        }

        public static void GrabBug()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GameObject.Find("Floating Bug Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
            }
            if (ControllerInputPoller.instance.leftGrab)
            {
                GameObject.Find("Floating Bug Holdable").transform.position = GorillaTagger.Instance.leftHandTransform.position;
            }
        }

        public static void GrabBat()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
            }
            if (ControllerInputPoller.instance.leftGrab)
            {
                GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.leftHandTransform.position;
            }
        }


        private static GameObject bug = GameObject.Find("Floating Bug Holdable");
        private static GameObject bat = GameObject.Find("Cave Bat Holdable");


        public static void OffMouthMovement()
        {
            GorillaTagger.Instance.offlineVRRig.GetComponent<GorillaMouthFlap>().enabled = false;
        }

        public static void OnMouthMovement()
        {
            GorillaTagger.Instance.offlineVRRig.GetComponent<GorillaMouthFlap>().enabled = true;
        }

        [Obsolete]
        public static void FPSboost()
        {
            fps = true;
            if (fps)
            {
                QualitySettings.masterTextureLimit = 999999999;
                QualitySettings.masterTextureLimit = 999999999;
                QualitySettings.globalTextureMipmapLimit = 999999999;
                QualitySettings.maxQueuedFrames = 60;
            }
        }

        [Obsolete]
        public static void fixFPS()
        {
            if (fps)
            {
                QualitySettings.masterTextureLimit = default;
                QualitySettings.masterTextureLimit = default;
                QualitySettings.globalTextureMipmapLimit = default;
                QualitySettings.maxQueuedFrames = default;
                fps = false;
            }
        }
        #endregion
        #region Save-Load Buttons & Settings
        public static void Save1()
        {
            List<string> list = new List<string>();
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons1)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons2)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons3)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons4)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons5)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons6)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons7)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons8)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons9)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            foreach (ButtonInfo buttonInfo in WristMenu.CatButtons10)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null)
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            File.WriteAllLines(WristMenu.FolderName + "\\Saved_Buttons.txt", list);
            NotifiLib.SendNotification("<color=white>[</color><color=blue>SAVE</color><color=white>]</color> <color=white>Saved Buttons Successfully!</color>");
        }
        public static void Load1()
        {
            string[] array = File.ReadAllLines(WristMenu.FolderName + "\\Saved_Buttons.txt");
            foreach (string b in array)
            {
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons1)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons2)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons3)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons4)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons5)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons6)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons7)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons8)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons9)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
                foreach (ButtonInfo buttonInfo in WristMenu.CatButtons10)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
            }
            NotifiLib.SendNotification("<color=white>[</color><color=blue>LOAD</color><color=white>]</color> <color=white>Loaded Buttons Successfully!</color>");
        }
        public static void Save()
        {
            List<string> list = new List<string>();
            foreach (ButtonInfo buttonInfo in WristMenu.settingsbuttons)
            {
                bool? enabled = buttonInfo.enabled;
                bool flag = true;
                if (enabled.GetValueOrDefault() == flag & enabled != null && buttonInfo.buttonText != "Save Settings")
                {
                    list.Add(buttonInfo.buttonText);
                }
            }
            File.WriteAllLines(WristMenu.FolderName + "\\Saved_Settings.txt", list);
            string text4 = string.Concat(new string[]
            {
               change1.ToString(),
               "\n",
               change2.ToString(),
               "\n",
               change3.ToString(),
               "\n",
               change4.ToString(),
               "\n",
               change6.ToString(),
               "\n",
               change7.ToString(),
               "\n",
               change8.ToString(),
               "\n",
               change9.ToString(),
               "\n",
               change10.ToString(),
               "\n",
               change11.ToString(),
               "\n",
               change12.ToString(),
               "\n",
               change13.ToString(),
               "\n",
               change14.ToString(),
               "\n",
               change15.ToString(),
               "\n",
               change16.ToString()
            });
            File.WriteAllText(WristMenu.FolderName + "/Saved_Settings2.txt", text4.ToString());
            NotifiLib.SendNotification("<color=white>[</color><color=blue>SAVE</color><color=white>]</color> <color=white>Saved Settings Successfully!</color>");
        }
        public static void Load()
        {
            string[] array = File.ReadAllLines(WristMenu.FolderName + "\\Saved_Settings.txt");
            foreach (string b in array)
            {
                foreach (ButtonInfo buttonInfo in WristMenu.settingsbuttons)
                {
                    if (buttonInfo.buttonText == b)
                    {
                        buttonInfo.enabled = new bool?(true);
                    }
                }
            }
            try
            {
                string text3 = File.ReadAllText(WristMenu.FolderName + "/Saved_Settings2.txt");
                string[] array4 = text3.Split(new string[] { "\n" }, StringSplitOptions.None);
                change1 = int.Parse(array4[0]) - 1;
                Changeplat();
                change2 = int.Parse(array4[1]) - 1;
                Changenoti();
                change3 = int.Parse(array4[2]) - 1;
                ChangeFPS();
                change4 = int.Parse(array4[3]) - 1;
                Changedisconnect();
                change6 = int.Parse(array4[4]) - 1;
                Changemenu();
                change7 = int.Parse(array4[5]) - 1;
                Changepagebutton();
                change8 = int.Parse(array4[6]) - 1;
                ChangeOrbColor();
                change9 = int.Parse(array4[7]) - 1;
                ChangeVisualColor();
                change10 = int.Parse(array4[8]) - 1;
                ThemeChangerV1();
                change11 = int.Parse(array4[9]) - 1;
                ThemeChangerV2();
                change12 = int.Parse(array4[10]) - 1;
                ThemeChangerV3();
                change13 = int.Parse(array4[11]) - 1;
                ThemeChangerV4();
                change14 = int.Parse(array4[12]) - 1;
                ThemeChangerV5();
                change15 = int.Parse(array4[13]) - 1;
                ThemeChangerV6();
                change16 = int.Parse(array4[14]) - 1;
                ThemeChangerV7();
            }
            catch
            {
            }
            NotifiLib.SendNotification("<color=white>[</color><color=blue>LOAD</color><color=white>]</color> <color=white>Loaded settings successfully!</color>");
        }
        #endregion
        #region Platform Shit
        // sticky plats r broke still srry
        private static void PlatformsThing(bool invis, bool sticky)
        {
            if (TriggerPlats)
            {
                RPlat = WristMenu.triggerDownR;
                LPlat = WristMenu.triggerDownL;
            }
            else
            {
                RPlat = WristMenu.gripDownR;
                LPlat = WristMenu.gripDownL;
            }
            if (RPlat)
            {
                if (!once_right && jump_right_local == null)
                {
                    if (sticky)
                    {
                        jump_right_local = GameObject.CreatePrimitive(0);
                    }
                    else
                    {
                        jump_right_local = GameObject.CreatePrimitive((PrimitiveType)3);
                    }
                    if (invis)
                    {
                        Destroy(jump_right_local.GetComponent<Renderer>());
                    }
                    jump_right_local.transform.localScale = scale;
                    jump_right_local.transform.position = new Vector3(0f, -0.01f, 0f) + GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                    jump_right_local.transform.rotation = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.rotation;
                    jump_right_local.AddComponent<GorillaSurfaceOverride>().overrideIndex = jump_right_local.GetComponent<GorillaSurfaceOverride>().overrideIndex;
                    once_right = true;
                    once_right_false = false;
                    ColorChanger colorChanger1 = jump_right_local.AddComponent<ColorChanger>();
                    colorChanger1.colors = new Gradient
                    {
                        colorKeys = colorKeysPlatformMonke
                    };
                    colorChanger1.Start();
                }
            }
            else
            {
                if (!once_right_false && jump_right_local != null)
                {
                    Destroy(jump_right_local.GetComponent<Collider>());
                    Rigidbody platr = jump_right_local.AddComponent(typeof(Rigidbody)) as Rigidbody;
                    platr.velocity = GorillaLocomotion.GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 5);
                    Destroy(jump_right_local, 2.0f);
                    jump_right_local = null;
                    once_right = false;
                    once_right_false = true;
                }
            }
            if (LPlat)
            {
                if (!once_left && jump_left_local == null)
                {
                    if (sticky)
                    {
                        jump_left_local = GameObject.CreatePrimitive(0);
                    }
                    else
                    {
                        jump_left_local = GameObject.CreatePrimitive((PrimitiveType)3);
                    }
                    if (invis)
                    {
                        Destroy(jump_left_local.GetComponent<Renderer>());
                    }
                    jump_left_local.transform.localScale = scale;
                    jump_left_local.transform.position = new Vector3(0f, -0.01f, 0f) + GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.position;
                    jump_left_local.transform.rotation = GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.rotation;
                    jump_left_local.AddComponent<GorillaSurfaceOverride>().overrideIndex = jump_left_local.GetComponent<GorillaSurfaceOverride>().overrideIndex;
                    once_left = true;
                    once_left_false = false;
                    ColorChanger colorChanger2 = jump_left_local.AddComponent<ColorChanger>();
                    colorChanger2.colors = new Gradient
                    {
                        colorKeys = colorKeysPlatformMonke
                    };
                    colorChanger2.Start();
                }
            }
            else
            {
                if (!once_left_false && jump_left_local != null)
                {
                    Destroy(jump_left_local.GetComponent<Collider>());
                    Rigidbody comp = jump_left_local.AddComponent(typeof(Rigidbody)) as Rigidbody;
                    comp.velocity = GorillaLocomotion.GTPlayer.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 5);
                    Destroy(jump_left_local, 2.0f);
                    jump_left_local = null;
                    once_left = false;
                    once_left_false = true;
                }
            }
            if (!PhotonNetwork.InRoom)
            {
                for (int i = 0; i < jump_right_network.Length; i++)
                {
                    Destroy(jump_right_network[i]);
                }
                for (int j = 0; j < jump_left_network.Length; j++)
                {
                    Destroy(jump_left_network[j]);
                }
            }
        }
#endregion
        #region GetButton
        public static ButtonInfo GetButton(string name)
        {
            foreach (ButtonInfo b in WristMenu.buttons)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.settingsbuttons)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons1)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons2)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons3)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons4)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons5)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons6)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons7)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons8)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons9)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            foreach (ButtonInfo b in WristMenu.CatButtons10)
            {
                if (b.buttonText == name)
                {
                    return b;
                }
            }
            return null;
        }
        #endregion
        #region Category shit
        public static void Settings()
        {
            WristMenu.settingsbuttons[0].enabled = new bool?(false);
            WristMenu.buttons[2].enabled = new bool?(false);
            inSettings = !inSettings;
            if (inSettings)
            {
                WristMenu.pageNumber = 0;
            }
            if (!inSettings)
            {
                WristMenu.pageNumber = 0;
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat1()
        {
            WristMenu.CatButtons1[0].enabled = new bool?(false);
            WristMenu.buttons[3].enabled = new bool?(false);
            inCat1 = !inCat1;
            if (inCat1)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat1)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat1)
                {
                    WristMenu.pageNumber = 0;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat2()
        {
            WristMenu.CatButtons2[0].enabled = new bool?(false);
            WristMenu.buttons[4].enabled = new bool?(false);
            inCat2 = !inCat2;
            if (inCat2)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat2)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat2)
                {
                    WristMenu.pageNumber = 0;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat3()
        {
            WristMenu.CatButtons3[0].enabled = new bool?(false);
            WristMenu.buttons[5].enabled = new bool?(false);
            inCat3 = !inCat3;
            if (inCat3)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat3)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat3)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat4()
        {
            WristMenu.CatButtons4[0].enabled = new bool?(false);
            WristMenu.buttons[6].enabled = new bool?(false);
            inCat4 = !inCat4;
            if (inCat4)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat4)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat4)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat5()
        {
            WristMenu.CatButtons5[0].enabled = new bool?(false);
            WristMenu.buttons[7].enabled = new bool?(false);
            inCat5 = !inCat5;
            if (inCat5)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat5)
                {
                    WristMenu.pageNumber = 2;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat5)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat6()
        {
            WristMenu.CatButtons6[0].enabled = new bool?(false);
            WristMenu.buttons[8].enabled = new bool?(false);
            inCat6 = !inCat6;
            if (inCat6)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat6)
                {
                    WristMenu.pageNumber = 2;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat6)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat7()
        {
            WristMenu.CatButtons7[0].enabled = new bool?(false);
            WristMenu.buttons[9].enabled = new bool?(false);
            inCat7 = !inCat7;
            if (inCat7)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat7)
                {
                    WristMenu.pageNumber = 2;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat7)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat8()
        {
            WristMenu.CatButtons8[0].enabled = new bool?(false);
            WristMenu.buttons[10].enabled = new bool?(false);
            inCat8 = !inCat8;
            if (inCat8)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat8)
                {
                    WristMenu.pageNumber = 2;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat8)
                {
                    WristMenu.pageNumber = 1;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat9()
        {
            WristMenu.CatButtons9[0].enabled = new bool?(false);
            WristMenu.buttons[11].enabled = new bool?(false);
            inCat9 = !inCat9;
            if (inCat9)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat9)
                {
                    WristMenu.pageNumber = 2;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat9)
                {
                    WristMenu.pageNumber = 2;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        public static void Cat10()
        {
            WristMenu.CatButtons10[0].enabled = new bool?(false);
            WristMenu.buttons[12].enabled = new bool?(false);
            inCat10 = !inCat10;
            if (inCat10)
            {
                WristMenu.pageNumber = 0;
            }
            if (change7 == 1)
            {
                if (!inCat10)
                {
                    WristMenu.pageNumber = 3;
                }
            }
            if (change7 == 2 | change7 == 3 | change7 == 4 | change7 == 5)
            {
                if (!inCat10)
                {
                    WristMenu.pageNumber = 2;
                }
            }
            WristMenu.DestroyMenu();
            WristMenu.instance.Draw();
        }
        #endregion
        #region Changers
        // DO NOT MESS WITH ANY OF THE THEME CHANGERS OR CHANGERS
        public static void Changeplat()
        {
            change1++;
            if (change1 > 2)
            {
                change1 = 1;
            }
            if (change1 == 1)
            {
                TriggerPlats = false;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>PLATFORMS</color><color=white>] Enable Platforms: Grips</color>");
            }
            if (change1 == 2)
            {
                TriggerPlats = true;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>PLATFORMS</color><color=white>] Enable Platforms: Triggers</color>");
            }
        }
        public static void Changenoti()
        {
            change2++;
            if (change2 > 2)
            {
                change2 = 1;
            }
            if (change2 == 1)
            {
                NotifiLib.IsEnabled = true;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>NOTIS</color><color=white>] Notis Enabled: Yes</color>");
            }
            if (change2 == 2)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>NOTIS</color><color=white>] Notis Enabled: No</color>");
                NotifiLib.IsEnabled = false;
            }
        }
        public static void ChangeFPS()
        {
            change3++;
            if (change3 > 2)
            {
                change3 = 1;
            }
            if (change3 == 1)
            {
                FPSPage = false;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>FPS & PAGE COUNTER</color><color=white>] Is Enabled: No</color>");
            }
            if (change3 == 2)
            {
                FPSPage = true;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>FPS & PAGE COUNTER</color><color=white>] Is Enabled: Yes</color>");
            }
        }
        public static void Changedisconnect()
        {
            change4++;
            if (change4 > 4)
            {
                change4 = 1;
            }
            if (change4 == 1)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>DISCONNECT BUTTON</color><color=white>] Disconnect Location: Right Side</color>");
            }
            if (change4 == 2)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>DISCONNECT BUTTON</color><color=white>] Disconnect Location: Left Side</color>");
            }
            if (change4 == 3)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>DISCONNECT BUTTON</color><color=white>] Disconnect Location: Top</color>");
            }
            if (change4 == 4)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>DISCONNECT BUTTON</color><color=white>] Disconnect Location: Bottom</color>");
            }
        }
        public static void Changemenu()
        {
            change6++;
            if (change6 > 2)
            {
                change6 = 1;
            }
            if (change6 == 1)
            {
                right = false;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>MENU LOCATION</color><color=white>] Current Location: Left Hand</color>");
            }
            if (change6 == 2)
            {
                right = true;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>MENU LOCATION</color><color=white>] Current Location: Right Hand</color>");
            }
        }
        public static void Changepagebutton()
        {
            change7++;
            if (change7 > 5)
            {
                change7 = 1;
            }
            if (change7 == 1)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: On Menu</color>");
            }
            if (change7 == 2)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: Top</color>");
            }
            if (change7 == 3)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: Sides</color>");
            }
            if (change7 == 4)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: Bottom</color>");
            }
            if (change7 == 5)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: Triggers</color>");
            }
        }
        public static void ChangeOrbColor()
        {
            change8++;
            if (change8 > 9)
            {
                change8 = 1;
            }
            if (change8 == 1)
            {
                CurrentGunColor = Color.blue;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: Blue</color>");
            }
            if (change8 == 2)
            {
                CurrentGunColor = Color.red;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: Red</color>");
            }
            if (change8 == 3)
            {
                CurrentGunColor = Color.white;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: White</color>");
            }
            if (change8 == 4)
            {
                CurrentGunColor = Color.green;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: Green</color>");
            }
            if (change8 == 5)
            {
                CurrentGunColor = Color.magenta;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: Magenta</color>");
            }
            if (change8 == 6)
            {
                CurrentGunColor = Color.cyan;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: Cyan</color>");
            }
            if (change8 == 7)
            {
                CurrentGunColor = Color.yellow;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: Yellow</color>");
            }
            if (change8 == 8)
            {
                CurrentGunColor = Color.black;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: Black</color>");
            }
            if (change8 == 9)
            {
                CurrentGunColor = Color.grey;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN & HAND ORB COLOR</color><color=white>] Current Color: Grey</color>");
            }
        }
        public static void ChangeVisualColor()
        {
            change9++;
            if (change9 > 9)
            {
                change9 = 1;
            }
            if (change9 == 1)
            {
                CurrentESPColor = Color.blue;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Blue</color>");
            }
            if (change9 == 2)
            {
                CurrentESPColor = Color.red;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Red</color>");
            }
            if (change9 == 3)
            {
                CurrentESPColor = Color.white;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: White</color>");
            }
            if (change9 == 4)
            {
                CurrentESPColor = Color.green;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Green</color>");
            }
            if (change9 == 5)
            {
                CurrentESPColor = Color.magenta;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Magenta</color>");
            }
            if (change9 == 6)
            {
                CurrentESPColor = Color.cyan;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Cyan</color>");
            }
            if (change9 == 7)
            {
                CurrentESPColor = Color.yellow;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Yellow</color>");
            }
            if (change9 == 8)
            {
                CurrentESPColor = Color.black;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Black</color>");
            }
            if (change9 == 9)
            {
                CurrentESPColor = Color.grey;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Grey</color>");
            }
        }
        public static void ThemeChangerV1()
        {
            change10++;
            if (change10 > 11)
            {
                change10 = 1;
            }
            if (change10 == 1)
            {
                if (WristMenu.ChangingColors)
                {
                    RGBMenu = false;
                    WristMenu.FirstColor = Color.blue;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Blue</color>");
                }
                else
                {
                    RGBMenu = false;
                    WristMenu.NormalColor = Color.blue;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Blue</color>");
                }
            }
            if (change10 == 2)
            {
                if (WristMenu.ChangingColors)
                {
                    WristMenu.FirstColor = Color.red;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Red</color>");
                }
                else
                {
                    WristMenu.NormalColor = Color.red;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Red</color>");
                }
            }
            if (change10 == 3)
            {
                if (WristMenu.ChangingColors)
                {
                    WristMenu.FirstColor = Color.white;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: White</color>");
                }
                else
                {
                    WristMenu.NormalColor = Color.white;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: White</color>");
                }
            }
            if (change10 == 4)
            {
                if (WristMenu.ChangingColors)
                {
                    WristMenu.FirstColor = Color.green;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Green</color>");
                }
                else
                {
                    WristMenu.NormalColor = Color.green;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Green</color>");
                }
            }
            if (change10 == 5)
            {
                if (WristMenu.ChangingColors)
                {
                    WristMenu.FirstColor = Color.magenta;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Magenta</color>");
                }
                else
                {
                    WristMenu.NormalColor = Color.magenta;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Magenta</color>");
                }
            }
            if (change10 == 6)
            {
                if (WristMenu.ChangingColors)
                {
                    WristMenu.FirstColor = Color.cyan;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Cyan</color>");
                }
                else
                {
                    WristMenu.NormalColor = Color.cyan;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Cyan</color>");
                }
            }
            if (change10 == 7)
            {
                if (WristMenu.ChangingColors)
                {
                    WristMenu.FirstColor = Color.yellow;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Yellow</color>");
                }
                else
                {
                    WristMenu.NormalColor = Color.yellow;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Yellow</color>");
                }
            }
            if (change10 == 8)
            {
                if (WristMenu.ChangingColors)
                {
                    WristMenu.FirstColor = Color.black;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Black</color>");
                }
                else
                {
                    WristMenu.NormalColor = Color.black;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Black</color>");
                }
            }
            if (change10 == 9)
            {
                if (WristMenu.ChangingColors)
                {
                    WristMenu.FirstColor = Color.grey;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Grey</color>");
                }
                else
                {
                    WristMenu.NormalColor = Color.grey;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Grey</color>");
                }
            }
            if (change10 == 10)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Clear</color>");
            }
            if (change10 == 11)
            {
                if (WristMenu.ChangingColors)
                {
                    RGBMenu = true;
                    NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: RGB</color>");
                }
                else
                {
                    NotifiLib.SendNotification("<color=white>[</color><color=red>ERROR</color><color=white>] Cannot Change The Menu To RGB Due To WristMenu.ChangingColors Being false</color>");
                }
            }
        }
        public static void ThemeChangerV2()
        {
            change11++;
            if (change11 > 9)
            {
                change11 = 1;
            }
            if (change11 == 1)
            {
                WristMenu.SecondColor = Color.black;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Black</color>");
            }
            if (change11 == 2)
            {
                WristMenu.SecondColor = Color.red;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Red</color>");
            }
            if (change11 == 3)
            {
                WristMenu.SecondColor = Color.white;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: White</color>");
            }
            if (change11 == 4)
            {
                WristMenu.SecondColor = Color.green;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Green</color>");
            }
            if (change11 == 5)
            {
                WristMenu.SecondColor = Color.magenta;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Magenta</color>");
            }
            if (change11 == 6)
            {
                WristMenu.SecondColor = Color.cyan;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Cyan</color>");
            }
            if (change11 == 7)
            {
                WristMenu.SecondColor = Color.yellow;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Yellow</color>");
            }
            if (change11 == 8)
            {
                WristMenu.SecondColor = Color.blue;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Blue</color>");
            }
            if (change11 == 9)
            {
                WristMenu.SecondColor = Color.grey;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Grey</color>");
            }
        }
        public static void ThemeChangerV3()
        {
            change12++;
            if (change12 > 10)
            {
                change12 = 1;
            }
            if (change12 == 1)
            {
                WristMenu.ButtonColorDisable = Color.yellow;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Yellow</color>");
            }
            if (change12 == 2)
            {
                WristMenu.ButtonColorDisable = Color.red;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Red</color>");
            }
            if (change12 == 3)
            {
                WristMenu.ButtonColorDisable = Color.white;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: White</color>");
            }
            if (change12 == 4)
            {
                WristMenu.ButtonColorDisable = Color.green;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Green</color>");
            }
            if (change12 == 5)
            {
                WristMenu.ButtonColorDisable = Color.magenta;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Magenta</color>");
            }
            if (change12 == 6)
            {
                WristMenu.ButtonColorDisable = Color.cyan;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Cyan</color>");
            }
            if (change12 == 7)
            {
                WristMenu.ButtonColorDisable = Color.black;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Black</color>");
            }
            if (change12 == 8)
            {
                WristMenu.ButtonColorDisable = Color.blue;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Blue</color>");
            }
            if (change12 == 9)
            {
                WristMenu.ButtonColorDisable = Color.grey;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Grey</color>");
            }
            if (change12 == 10)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Clear</color>");
            }
        }
        public static void ThemeChangerV4()
        {
            change13++;
            if (change13 > 10)
            {
                change13 = 1;
            }
            if (change13 == 1)
            {
                WristMenu.ButtonColorEnabled = Color.magenta;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Magenta</color>");
            }
            if (change13 == 2)
            {
                WristMenu.ButtonColorEnabled = Color.red;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Red</color>");
            }
            if (change13 == 3)
            {
                WristMenu.ButtonColorEnabled = Color.white;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: White</color>");
            }
            if (change13 == 4)
            {
                WristMenu.ButtonColorEnabled = Color.green;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Green</color>");
            }
            if (change13 == 5)
            {
                WristMenu.ButtonColorEnabled = Color.yellow;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Yellow</color>");
            }
            if (change13 == 6)
            {
                WristMenu.ButtonColorEnabled = Color.cyan;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Cyan</color>");
            }
            if (change13 == 7)
            {
                WristMenu.ButtonColorEnabled = Color.black;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Black</color>");
            }
            if (change13 == 8)
            {
                WristMenu.ButtonColorEnabled = Color.blue;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Blue</color>");
            }
            if (change13 == 9)
            {
                WristMenu.ButtonColorEnabled = Color.grey;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Grey</color>");
            }
            if (change13 == 10)
            {
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Clear</color>");
            }
        }
        public static void ThemeChangerV5()
        {
            change14++;
            if (change14 > 9)
            {
                change14 = 1;
            }
            if (change14 == 1)
            {
                WristMenu.EnableTextColor = Color.black;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Black</color>");
            }
            if (change14 == 2)
            {
                WristMenu.EnableTextColor = Color.red;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Red</color>");
            }
            if (change14 == 3)
            {
                WristMenu.EnableTextColor = Color.white;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: White</color>");
            }
            if (change14 == 4)
            {
                WristMenu.EnableTextColor = Color.green;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Green</color>");
            }
            if (change14 == 5)
            {
                WristMenu.EnableTextColor = Color.yellow;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Yellow</color>");
            }
            if (change14 == 6)
            {
                WristMenu.EnableTextColor = Color.cyan;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Cyan</color>");
            }
            if (change14 == 7)
            {
                WristMenu.EnableTextColor = Color.magenta;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Magenta</color>");
            }
            if (change14 == 8)
            {
                WristMenu.EnableTextColor = Color.blue;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Blue</color>");
            }
            if (change14 == 9)
            {
                WristMenu.EnableTextColor = Color.grey;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Grey</color>");
            }
        }
        public static void ThemeChangerV6()
        {
            change15++;
            if (change15 > 9)
            {
                change15 = 1;
            }
            if (change15 == 1)
            {
                WristMenu.DIsableTextColor = Color.black;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Black</color>");
            }
            if (change15 == 2)
            {
                WristMenu.DIsableTextColor = Color.red;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Red</color>");
            }
            if (change15 == 3)
            {
                WristMenu.DIsableTextColor = Color.white;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: White</color>");
            }
            if (change15 == 4)
            {
                WristMenu.DIsableTextColor = Color.green;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Green</color>");
            }
            if (change15 == 5)
            {
                WristMenu.DIsableTextColor = Color.yellow;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Yellow</color>");
            }
            if (change15 == 6)
            {
                WristMenu.DIsableTextColor = Color.cyan;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Cyan</color>");
            }
            if (change15 == 7)
            {
                WristMenu.DIsableTextColor = Color.magenta;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Magenta</color>");
            }
            if (change15 == 8)
            {
                WristMenu.DIsableTextColor = Color.blue;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Blue</color>");
            }
            if (change15 == 9)
            {
                WristMenu.DIsableTextColor = Color.grey;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Grey</color>");
            }
        }
        public static void ThemeChangerV7()
        {
            change16++;
            if (change16 > 6)
            {
                change16 = 1;
            }
            if (change16 == 1)
            {
                ButtonSound = 67;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: Normal</color>");
            }
            if (change16 == 2)
            {
                ButtonSound = 8;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: Stump</color>");
            }
            if (change16 == 3)
            {
                ButtonSound = 203;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: AK47</color>");
            }
            if (change16 == 4)
            {
                ButtonSound = 50;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: Glass</color>");
            }
            if (change16 == 5)
            {
                ButtonSound = 66;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: KeyBoard</color>");
            }
            if (change16 == 6)
            {
                ButtonSound = 114;
                NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: Cayon Bridge</color>"); // this sounds the best tbh
            }
        }
        #endregion
        #region GunLib
        public static void MakeGun(Color color, Vector3 pointersize, float linesize, PrimitiveType pointershape, Transform arm, bool liner, Action shit, Action shit1)
        {
            if (arm == GorillaLocomotion.GTPlayer.Instance.rightControllerTransform)
            {
                hand = WristMenu.gripDownR;
                hand1 = WristMenu.triggerDownR;
            }
            else if (arm == GorillaLocomotion.GTPlayer.Instance.leftControllerTransform)
            {
                hand = WristMenu.gripDownL;
                hand1 = WristMenu.triggerDownL;
            }
            if (hand)
            {
                Physics.Raycast(arm.position, -arm.up, out raycastHit);
                if (pointer == null) { pointer = GameObject.CreatePrimitive(pointershape); }
                pointer.transform.localScale = pointersize;
                pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                pointer.transform.position = raycastHit.point;
                pointer.GetComponent<Renderer>().material.color = color;
                if (liner)
                {
                    GameObject g = new GameObject("Line");
                    Line = g.AddComponent<LineRenderer>();
                    Line.material.shader = Shader.Find("GUI/Text Shader");
                    Line.startWidth = linesize;
                    Line.endWidth = linesize;
                    Line.startColor = color;
                    Line.endColor = color;
                    Line.positionCount = 2;
                    Line.useWorldSpace = true;
                    Line.SetPosition(0, arm.position);
                    Line.SetPosition(1, pointer.transform.position);
                    Destroy(g, Time.deltaTime);
                }
                Destroy(pointer.GetComponent<BoxCollider>());
                Destroy(pointer.GetComponent<Rigidbody>());
                Destroy(pointer.GetComponent<Collider>());
                if (hand1)
                {
                    shit.Invoke();
                }
                else
                {
                    shit1.Invoke();
                }
            }
            else
            {
                if (pointer != null)
                {
                    Destroy(pointer, Time.deltaTime);
                }
            }
        }
        // here are some examples of how to use the gunlib
        // this example is for when u only want to execute code when holding ur trigger
        #endregion
        #region Vars
        // category vars
        public static bool inSettings = false;
        public static bool inCat1 = false;
        public static bool inCat2 = false;
        public static bool inCat3 = false;
        public static bool inCat4 = false;
        public static bool inCat5 = false;
        public static bool inCat6 = false;
        public static bool inCat7 = false;
        public static bool inCat8 = false;
        public static bool inCat9 = false;
        public static bool inCat10 = false;
        // color vars
        public static Color CurrentGunColor = Color.blue;
        public static Color CurrentESPColor = Color.blue;
        // changers
        public static int change1 = 1;
        public static int change2 = 1;
        public static int change3 = 2;
        public static int change4 = 3;
        public static int change6 = 1;
        public static int change7 = 4;
        public static int change8 = 1;
        public static int change9 = 1;
        public static int change10 = 1;
        public static int change11 = 1;
        public static int change12 = 1;
        public static int change13 = 1;
        public static int change14 = 1;
        public static int change15 = 1;
        public static int change16 = 1;
        // rig vars
        public static bool ghostMonke = false;
        public static bool rightHand = false;
        public static bool lastHit;
        public static bool lastHit2;
        public static GameObject orb;
        public static GameObject orb2;
        // random vars
        public static bool FPSPage;
        public static bool RGBMenu;
        public static bool right;
        public static bool fps;
        public static int ButtonSound = 67;
        public static float balll435342111;
        // gun vars
        public static GameObject pointer = null;
        public static LineRenderer Line;
        public static RaycastHit raycastHit;
        public static bool hand = false;
        public static bool hand1 = false;
        // platform vars
        public static bool invisplat = false;
        public static bool invisMonke = false;
        public static bool stickyplatforms = false;
        private static Vector3 scale = new Vector3(0.0125f, 0.28f, 0.3825f);
        private static bool once_left;
        private static bool once_right;
        private static bool once_left_false;
        private static bool once_right_false;
        private static GameObject[] jump_left_network = new GameObject[9999];
        private static GameObject[] jump_right_network = new GameObject[9999];
        private static GameObject jump_left_local = null;
        private static GameObject jump_right_local = null;
        private static GradientColorKey[] colorKeysPlatformMonke = new GradientColorKey[4];
        public static bool TriggerPlats;
        public static bool RPlat;
        public static bool LPlat;
        #endregion
    }
}

